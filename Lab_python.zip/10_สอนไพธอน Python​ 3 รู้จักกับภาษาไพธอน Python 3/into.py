print(3*4)
p=22/7
print(p)
p=45
print(p)
m1 = "pikachu" #string
m2 = 'phydom'
isAdult = True #boolean
print(m1)
print(m1 +' vs. '+ m2)