w = input("width = ")# string '5' "5"
h = input("height = ") #'3'
# print(w * h)
# print(5*3)
# dynamic typing

w = int(input("width = ")) # int
print(type(w))
a = 5
print(a)
print(type(a)) # integer
b = 5.0
print(b)
print(type(b))
c = 1/3
print(c)
# h = int(input("height = "))