a = 7
b = 3
print(a + b)
print(a - b)
print(a * b)
print(a / b)
print(a // b) #หารไม่เอาเศษ
print(a % b) #หารเอาเเศษ การทำ mod
print(a ** b) #ยกกำลัง

f = 32 + 37 *9 / 2 ** 3 # ** * / + -
d = (32 + ((37 *9) / (2 ** 3))) -1
print(f)
print(d)