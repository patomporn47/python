# flowers = "lily","rose","daisy","tulip"
# if "calla" in flowers:
#     print("available")
# else:
#     print("not available")

# sentence = "over the rainbow"
# if "rain" in sentence:
#     print("ok")
# else:
#     print("not ok")

n = 10, 8, 15, 30, 60
if 15.0 in n:
    print("ok")
else:
    print("not ok")
